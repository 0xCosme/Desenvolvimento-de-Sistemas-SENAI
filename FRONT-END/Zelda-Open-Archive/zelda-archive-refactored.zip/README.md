# Zelda Open Archive

Este projeto é uma refatoração de uma aplicação web que permite explorar criaturas, monstros, materiais e equipamentos do universo de Zelda, utilizando a [Hyrule Compendium API](https://botw-compendium.herokuapp.com/api/v3/compendium/). O objetivo principal desta refatoração foi melhorar a estética, modularidade, segurança, performance e legibilidade do código, seguindo as melhores práticas de desenvolvimento web e programação funcional.

## Funcionalidades

- **Exploração de Categorias:** Navegue por diferentes categorias (Equipamentos, Monstros, Criaturas, Materiais, Tesouros).
- **Pesquisa Dinâmica:** Busque itens específicos na API.
- **Detalhes de Itens:** Visualize informações detalhadas de cada item em um modal interativo.
- **Design Responsivo:** Interface adaptável a diferentes tamanhos de tela.
- **Efeitos Visuais:** Animações e efeitos de *glassmorphism* para uma experiência imersiva.

## Tecnologias Utilizadas

- **HTML5:** Estrutura semântica da página.
- **Tailwind CSS:** Framework CSS para estilização rápida e responsiva.
- **JavaScript (ES6+):** Lógica da aplicação, modularizada para melhor organização e manutenção.
- **Hyrule Compendium API:** Fonte de dados para os itens de Zelda.

## Estrutura do Projeto

O projeto foi organizado em uma estrutura modular para facilitar a manutenção e escalabilidade:

```
zelda-archive/
├── assets/
│   ├── css/
│   │   └── styles.css
│   └── js/
│       ├── api.js
│       ├── main.js
│       ├── ui.js
│       └── utils.js
└── index.html
└── README.md
```

- `index.html`: O arquivo HTML principal que estrutura a aplicação.
- `assets/css/styles.css`: Contém os estilos CSS personalizados, incluindo variáveis, animações e ajustes para o *glassmorphism*.
- `assets/js/api.js`: Módulo responsável por todas as interações com a Hyrule Compendium API, encapsulando as chamadas `fetch`.
- `assets/js/utils.js`: Módulo de funções utilitárias, como tradução de categorias, sanitização de strings e uma função segura para criação de elementos DOM (evitando `innerHTML`).
- `assets/js/ui.js`: Módulo dedicado à manipulação da interface do usuário (DOM), renderização de itens e gerenciamento do modal.
- `assets/js/main.js`: O módulo principal que orquestra a inicialização da aplicação, gerencia os ouvintes de eventos e integra os demais módulos.

## Como Rodar o Projeto

Para visualizar e interagir com o projeto localmente, siga os passos abaixo:

1.  **Clone o repositório (ou baixe os arquivos):**
    ```bash
    git clone <URL_DO_REPOSITORIO>
    cd zelda-archive
    ```
    (Se você recebeu os arquivos diretamente, apenas navegue até a pasta `zelda-archive`.)

2.  **Abra o arquivo `index.html`:**
    Simplesmente abra o arquivo `index.html` em seu navegador web preferido. Não é necessário um servidor web para esta aplicação estática.

## Boas Práticas e Melhorias Implementadas

### Modularidade

O código JavaScript foi dividido em módulos (`api.js`, `utils.js`, `ui.js`, `main.js`) utilizando `import`/`export` do ES6. Isso promove a separação de responsabilidades, tornando o código mais organizado, fácil de entender, testar e manter.

### Segurança

- **Remoção de `innerHTML`:** O uso direto de `innerHTML` foi substituído por manipulação segura do DOM através da função `createElement` no módulo `utils.js`. Isso previne ataques de Cross-Site Scripting (XSS), garantindo que nenhum script malicioso possa ser injetado na página.
- **Sanitização de Entrada:** A função `sanitizeSearch` em `utils.js` garante que as entradas do usuário sejam limpas antes de serem usadas em requisições à API, minimizando riscos de injeção ou comportamento inesperado.

### Performance

- **Carregamento Lazy de Imagens:** As imagens dos itens são carregadas com `loading="lazy"`, otimizando o desempenho inicial da página ao carregar apenas as imagens visíveis na tela.
- **Otimização de Requisições:** As chamadas à API são gerenciadas de forma assíncrona, e o tratamento de erros é implementado para garantir uma experiência de usuário fluida mesmo em caso de falhas na rede ou na API.
- **Animações CSS:** As animações são controladas por CSS, aproveitando a aceleração de hardware para transições suaves e eficientes.

### Estética e Código Limpo

- **Tailwind CSS:** Utilização de classes utilitárias do Tailwind para um design consistente e responsivo, com fácil personalização.
- **Variáveis CSS:** Definição de variáveis CSS (`:root`) para cores e propriedades comuns, facilitando a manutenção e padronização do estilo.
- **Comentários Detalhados:** O código foi extensivamente comentado para explicar a lógica, a finalidade de cada função/módulo e as decisões de design.
- **Nomenclatura Clara:** Variáveis, funções e classes foram nomeadas de forma descritiva e consistente.

### Programação Funcional

- **Funções Puras:** O módulo `utils.js` contém funções puras, que dado o mesmo input, sempre retornam o mesmo output e não causam efeitos colaterais. Isso melhora a previsibilidade e testabilidade do código.
- **Imutabilidade:** Preferência por operações que não modificam diretamente os dados originais, mas retornam novas estruturas de dados.
- **Composição de Funções:** O código é estruturado para permitir a composição de funções, onde a saída de uma função pode ser a entrada de outra, promovendo um fluxo de dados claro e conciso.

## Contribuição

Contribuições são bem-vindas! Sinta-se à vontade para abrir *issues* ou enviar *pull requests* para melhorias, correção de bugs ou novas funcionalidades.

## Licença

Este projeto está licenciado sob a licença MIT. Veja o arquivo `LICENSE` para mais detalhes. (Nota: O arquivo LICENSE não foi gerado nesta refatoração, mas é uma boa prática incluí-lo em projetos de código aberto.)

---

Desenvolvido com 💚 por Manus AI
